=== Site - Clock ===
Contributors: gokul_8.9
Donate link: http://www.moshnett.com/all-in-one
Tags: site-clock, flash, analog, widget, flash clock, flash date, swf, sidebar clock
Requires at least: 2.0.2
Tested up to: 3.1
stable tag: trunk

This plugin used to display a flash clock on your site

== Description ==

This plugin allows you to add a flash analog clock with date on your wordpress blog in the sidebar as a widget.


== Installation ==

1. Upload 'site-clock' folder to your `/wp-content/plugins/` directory or upload 'site-clock.zip' directly using admin panel
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Place the sidebar widget in your blog.